package com.example.postrequestpractice_laila

import android.content.Intent
import android.os.Bundle
import android.widget.Button
import androidx.appcompat.app.AppCompatActivity
import androidx.cardview.widget.CardView
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class ViewActivity : AppCompatActivity() {
    var Test_List = arrayListOf<UserDetails.User>()
    lateinit var RecyclerView : RecyclerView
    lateinit var Button_new_user: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_view)

        supportActionBar?.hide()


        RecyclerView = findViewById(R.id.Recycler_View)
        RecyclerView.adapter =Adapter(Test_List)
        RecyclerView.layoutManager = LinearLayoutManager(this)

        getRecipes()


    }


    private fun getRecipes(){
        val apiInterface = APIClient().getClient()?.create(APIInterface::class.java)

        apiInterface?.getUser()?.enqueue(object : Callback<List<UserDetails.User>> {
            override fun onResponse(
                call: Call<List<UserDetails.User>>,
                response: Response<List<UserDetails.User>>
            ) {

                val resource = response.body()!!
                for ( i in resource){

                    var Name = i.name.toString()
                    var Location = i.location.toString()
                    Test_List.add(UserDetails.User(Name,Location))

                }
                RecyclerView.adapter?.notifyDataSetChanged()

            }

            override fun onFailure(call: Call<List<UserDetails.User>>, t: Throwable) {
                call.cancel()
            }
        })

    }

    fun addnew(view: android.view.View) {
        intent = Intent(applicationContext, MainActivity::class.java)
        startActivity(intent)
    }
}