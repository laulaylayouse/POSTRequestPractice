package com.example.postrequestpractice_laila

import retrofit2.Call
import retrofit2.http.Body
import retrofit2.http.GET
import retrofit2.http.Headers
import retrofit2.http.POST

//https://dojo-recipes.herokuapp.com/recipes/

interface APIInterface {
    @Headers("Content-Type: application/json")
    @GET("/test/")
    fun getUser(): Call<List<UserDetails.User>>


    @Headers("Content-Type: application/json")
    @POST("/test/")
    fun addUser(@Body userData: UserDetails.User): Call<List<UserDetails.User>>


}