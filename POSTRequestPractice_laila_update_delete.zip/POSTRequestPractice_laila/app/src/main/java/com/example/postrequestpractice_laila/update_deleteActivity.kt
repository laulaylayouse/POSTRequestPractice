package com.example.postrequestpractice_laila

import android.app.ProgressDialog
import android.content.Intent
import android.os.Bundle
import android.view.Menu
import android.view.MenuItem
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class update_deleteActivity : AppCompatActivity() {

    lateinit var EditTextId: EditText
    lateinit var EditText_add_Name: EditText
    lateinit var EditText_add_Location: EditText

    lateinit var Button_Update: Button
    lateinit var Button_Delete: Button
    lateinit var Button_check: Button

    var name = ""
    var location = ""
    var pk:Int = 0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_update_delete)

        EditTextId = findViewById(R.id.EditTextId)
        EditText_add_Name = findViewById(R.id.EditText_add_Name)
        EditText_add_Location = findViewById(R.id.EditText_add_Location)

        Button_Update = findViewById(R.id.Button_Update)
        Button_Delete = findViewById(R.id.Button_Delete)
       // Button_check = findViewById(R.id.Button_ch)
//
//        supportActionBar?.hide()

        Button_Delete.setOnClickListener {

            pk = EditTextId.text.toString().toInt()
            deleteUser()
            EditText_add_Name.setText("")
            EditText_add_Location.setText("")
            EditTextId.setText("")
        }
        Button_Update.setOnClickListener {

            pk = EditTextId.text.toString().toInt()
            name = EditText_add_Name.text.toString()
            location= EditText_add_Location.text.toString()
            updateUser()
            EditText_add_Name.setText("")
            EditText_add_Location.setText("")
            EditTextId.setText("")
        }


    }

    override fun onCreateOptionsMenu(menu: Menu?): Boolean {
        menuInflater.inflate(R.menu.main_menu, menu)
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        when(item.itemId){
            R.id.View -> {
                intent = Intent(applicationContext, ViewActivity::class.java)
                startActivity(intent)
                return true
            }
            R.id.add ->
            {
                intent = Intent(applicationContext, MainActivity::class.java)
                startActivity(intent)
                return true

            }
        }
        return super.onOptionsItemSelected(item)
    }

    private fun updateUser() {

        val apiInterface = APIClient().getClient()?.create(APIInterface::class.java)
        val progressDialog = ProgressDialog(this)
        progressDialog.setMessage("Please wait")
        progressDialog.show()
        apiInterface?.updateUser(pk,UserDetails.User(pk,name,location))?.enqueue(object :
            Callback<List<UserDetails.User>> {
            override fun onResponse(
                call: Call<List<UserDetails.User>>,
                response: Response<List<UserDetails.User>>,
            ) {
                Toast.makeText(applicationContext, "User Updated Successfully!", Toast.LENGTH_SHORT).show()
                response.body()
                progressDialog.dismiss()
                intent = Intent(applicationContext, ViewActivity::class.java)
                startActivity(intent)
            }

            override fun onFailure(call: Call<List<UserDetails.User>>, t: Throwable) {
                progressDialog.dismiss()
                call.cancel()
            }

        })


    }

    private fun deleteUser() {
        val apiInterface = APIClient().getClient()?.create(APIInterface::class.java)
        val progressDialog = ProgressDialog(this)
        progressDialog.setMessage("Please wait")
        progressDialog.show()
        apiInterface?.deleteUser(pk)?.enqueue(object : Callback<Void> {
            override fun onResponse(call: Call<Void>, response: Response<Void>) {
                Toast.makeText(applicationContext, "User deleted" , Toast.LENGTH_SHORT).show()
                response.body()
                progressDialog.dismiss()
                intent = Intent(applicationContext, ViewActivity::class.java)
                startActivity(intent)
            }

            override fun onFailure(call: Call<Void>, t: Throwable) {
                progressDialog.dismiss()
                call.cancel()

            }
        })
    }
}