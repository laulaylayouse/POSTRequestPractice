package com.example.postrequestpractice_laila

import retrofit2.Call
import retrofit2.http.*

//https://dojo-recipes.herokuapp.com/recipes/

interface APIInterface {
    @Headers("Content-Type: application/json")
    @GET("/test/")
    fun getUser(): Call<List<UserDetails.User>>


    @Headers("Content-Type: application/json")
    @POST("/test/")
    fun addUser(@Body userData: UserDetails.User): Call<List<UserDetails.User>>

    @Headers("Content-Type: application/json")
    @PUT("/test/{pk}")
    fun updateUser(@Path("pk")pk:Int,@Body userData: UserDetails.User): Call<List<UserDetails.User>>

    @Headers("Content-Type: application/json")
    @DELETE("/test/{pk}")
    fun deleteUser(@Path("pk")pk:Int): Call<Void>


}