package com.example.postrequestpractice_laila

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class MainActivity : AppCompatActivity() {

    lateinit var EditText_add_Name: EditText
    lateinit var EditText_add_Location: EditText

    lateinit var Button_Save: Button
    lateinit var Button_View: Button

    var name = ""
    var location = ""
    var pk = 0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        supportActionBar?.hide()

        EditText_add_Name = findViewById(R.id.EditText_add_Name)
        EditText_add_Location = findViewById(R.id.EditText_add_Location)

        Button_Save = findViewById(R.id.Button_Save)
        Button_Save.setOnClickListener {

            name = EditText_add_Name.text.toString()
            location = EditText_add_Location.text.toString()

            if (name.isNotEmpty() &&
                location.isNotEmpty())
            {
                save_Recipe()
                Toast.makeText(this, "New Information is added!!", Toast.LENGTH_LONG).show()
            }
            else
            {
                Toast.makeText(this, "Please Enter a Information Correctly", Toast.LENGTH_LONG).show()
            }

            EditText_add_Name.setText("")
            EditText_add_Location.setText("")

        }

        Button_View = findViewById(R.id.Button_View)
        Button_View.setOnClickListener {
            val intent = Intent(this, ViewActivity::class.java)
            startActivity(intent) }

    }

    private fun save_Recipe() {
        val apiInterface = APIClient().getClient()?.create(APIInterface::class.java)


        apiInterface?.addUser(UserDetails.User(pk, name,location))?.enqueue(object :Callback<List<UserDetails.User>> {

            override fun onFailure(call: Call<List<UserDetails.User>>, t: Throwable) {
                call.cancel()
            }

            override fun onResponse(
                call: Call<List<UserDetails.User>>,
                response: Response<List<UserDetails.User>>
            ) {

                response.body()!!
            }

        }
        )
    }
}